import Navbar from "@/components/dashboard/Navbar"
import { authOptions, CustomSession } from "../api/auth/[...nextauth]/options"
import { getServerSession } from "next-auth"


async function Dashboard() {
  const session: CustomSession | null = await getServerSession(authOptions);
 
  console.log(session?.user?.name , session?.user?.image)
  return (
    <div>
      <Navbar name={session?.user?.name!} image={session?.user?.image ?? undefined}/>
    </div>
  )
}

export default Dashboard