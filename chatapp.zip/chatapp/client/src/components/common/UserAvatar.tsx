"use client"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

import React from 'react'

function UserAvatar({name , image}:{name:string; image?:string;}) {
  return (
    <Avatar>
    <AvatarImage src={image} />
    <AvatarFallback>{name}</AvatarFallback>
  </Avatar>
  
  )
}

export default UserAvatar