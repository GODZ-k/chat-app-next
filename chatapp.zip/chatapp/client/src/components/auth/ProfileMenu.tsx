"use client"
import React, { useState } from 'react'
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
  } from "@/components/ui/dropdown-menu"
import UserAvatar from '../common/UserAvatar'
import LougoutModel from './LougoutModel';
  

function ProfileMenu({name , image}:{
    name :string;
    image ?:string
}) {

    const [logoutOpen, setLogoutOpen] = useState(false);

  return (
    <>
     {logoutOpen && <LougoutModel open={logoutOpen} setOpen={setLogoutOpen} />}
    <DropdownMenu>
    <DropdownMenuTrigger>
        <UserAvatar image={image} name={name}/>
    </DropdownMenuTrigger>
    <DropdownMenuContent>
      <DropdownMenuLabel>My Account</DropdownMenuLabel>
      <DropdownMenuSeparator />
      <DropdownMenuItem>Profile</DropdownMenuItem>
      <DropdownMenuItem onClick={() => setLogoutOpen(true)}>Logout</DropdownMenuItem>
    </DropdownMenuContent>
  </DropdownMenu>  
     </>
  )
}

export default ProfileMenu