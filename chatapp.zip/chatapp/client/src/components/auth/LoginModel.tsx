"use client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "../ui/button";
import Image from "next/image";
import { signIn } from "next-auth/react";

function LoginModel() {

    const handleGoogleLogin = async () => {
        signIn("google", {
          redirect: true,
          callbackUrl: "/dashboard",
        });
      };
      
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button>Getting start</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className=" text-xl">Welcome to the chat app</DialogTitle>
          <DialogDescription>
            Please signup to getting start the robust chat application
          </DialogDescription>
        </DialogHeader>
        <Button variant={'outline'} onClick={handleGoogleLogin}>
            <Image
            src='/images/google.png'
            className=" mr-4"
            width={25}
            height={25}
            alt="google"
            />
        </Button>
      </DialogContent>
    </Dialog>
  );
}

export default LoginModel;
