(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_favicon_ico_mjs_e3431b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_favicon_ico_mjs_e3431b._.js",
  "chunks": [
    "static/chunks/_d86153._.js"
  ],
  "source": "dynamic"
});
