(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_600847._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_600847._.js",
  "chunks": [
    "static/chunks/src_app_c7d265._.css",
    "static/chunks/node_modules_88d3f0._.js",
    "static/chunks/src_38998c._.js"
  ],
  "source": "dynamic"
});
