(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_dashboard_page_tsx_3068de._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_dashboard_page_tsx_3068de._.js",
  "chunks": [
    "static/chunks/node_modules_@radix-ui_react-icons_dist_react-icons_esm_ecd85e.js",
    "static/chunks/node_modules_55321f._.js",
    "static/chunks/src_8ac3d5._.js"
  ],
  "source": "dynamic"
});
