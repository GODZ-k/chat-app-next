(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_3482bf._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_3482bf._.js",
  "chunks": [
    "static/chunks/node_modules_next_c89bfc._.js",
    "static/chunks/node_modules_@radix-ui_react-icons_dist_react-icons_esm_ecd85e.js",
    "static/chunks/node_modules_f6f971._.js",
    "static/chunks/src_4ce992._.js"
  ],
  "source": "dynamic"
});
