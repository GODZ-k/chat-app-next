import 'dotenv/config'
import express,{Request,Response} from 'express'
import { clerkMiddleware } from '@clerk/express'
import cookieParser from 'cookie-parser'
import cors from 'cors'
import authRouter from './routes/auth.route.js'

const app = express()
app.use(cors({
    origin:'*',
    credentials:true
}))
app.use(clerkMiddleware())
app.use(express.json({ limit:"100mb"}))
app.use(express.urlencoded({extended:false}))
app.use(cookieParser())



app.use('/api/v1/auth',authRouter)

  



export default app