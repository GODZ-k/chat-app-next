import { Request, Response } from "express";
import JWT from 'jsonwebtoken'
import prisma from "../config/db.config.js";
import { jwt_secret } from "../config/config.js";

interface LoginPayloadType {
  name: string;
  email: string;
  provider: string;
  oauth_id: string;
  image?: string;
}

class AuthController {
  static async login(req: Request, res: Response):Promise<any> {
    try {
      const body: LoginPayloadType = req.body;

      const isExists = await prisma.user.findUnique({
        where:{
            email:body.email
        }
      })

      if(!isExists){
       const user = await prisma.user.create({
            data:body
        })
        
        const JWTpayload = {
            name:body.name,
            email:body.email,
            id:user.id
        }

        const token = JWT.sign(JWTpayload,jwt_secret,{
            expiresIn:"10d"
        })

        return res.status(200).json({
            msg:"User logged in successfully",
            user:{
                ...user,
                token:`Bearer ${token}`
            }
        })

      }
    } catch (error) {
      return res.status(500).json({
        msg: "Internal server error",
      });
    }
  }
}



export default AuthController