import 'dotenv/config'

const port = process.env.PORT 
const jwt_secret = process.env.JWT_SECRET as string


export {
    port,
    jwt_secret
}