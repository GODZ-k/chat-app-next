import app from "./src/app.js";
import { port } from "./src/config/config.js";
import prisma from "./src/config/db.config.js";


prisma.$connect().then(() => {
  console.log("Connected to the PostgreSQL database successfully!");

  // Start the server after successful database connection
  app.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
  });
}).catch((error)=>{
    console.error("Error connecting to the database:", error);
    prisma.$disconnect();
    process.exit(1);
})


process.on('SIGINT', async () => {
    console.log("Shutting down...");
    await prisma.$disconnect();
    process.exit(0);
});
